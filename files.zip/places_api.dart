import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

// ─────────────────────────────────────────────────────────────
// Place model
// ─────────────────────────────────────────────────────────────
class Place {
  final String id;
  final String name;
  final String category;
  final int? elevationM;
  final double latitude;
  final double longitude;
  final double? averageRating;
  final int ratingCount;
  final String? description;
  final dynamic images; // jsonb — can be a List or null
  final Map<String, dynamic>? tags;

  const Place({
    required this.id,
    required this.name,
    required this.category,
    required this.latitude,
    required this.longitude,
    this.elevationM,
    this.averageRating,
    this.ratingCount = 0,
    this.description,
    this.images,
    this.tags,
  });

  factory Place.fromJson(Map<String, dynamic> j) {
    return Place(
      id: (j['id'] ?? '').toString(),
      name: (j['name'] ?? 'Unknown').toString(),
      category: (j['category'] ?? 'unknown').toString(),
      elevationM: j['elevation_m'] == null
          ? null
          : int.tryParse(j['elevation_m'].toString()),
      // API returns latitude/longitude extracted from geom via ST_Y/ST_X
      latitude: (j['latitude'] as num).toDouble(),
      longitude: (j['longitude'] as num).toDouble(),
      // API returns avg_rating (not average_rating)
      averageRating: j['avg_rating'] == null
          ? null
          : double.tryParse(j['avg_rating'].toString()),
      ratingCount: j['rating_count'] == null
          ? 0
          : int.tryParse(j['rating_count'].toString()) ?? 0,
      description: j['description']?.toString(),
      images: j['images'],
      tags: j['tags'] != null ? Map<String, dynamic>.from(j['tags']) : null,
    );
  }
}

// ─────────────────────────────────────────────────────────────
// PlacesApi — all calls go to your Express backend
// ─────────────────────────────────────────────────────────────
class PlacesApi {
  final String baseUrl;
  const PlacesApi({required this.baseUrl});

  // ── helpers ────────────────────────────────────────────────

  /// Returns the Firebase ID token for the current user.
  /// Throws if the user is not logged in.
  Future<String> _getToken() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User is not logged in');
    final token = await user.getIdToken();
    if (token == null) throw Exception('Could not retrieve auth token');
    return token;
  }

  Map<String, String> get _jsonHeaders => {
        'Content-Type': 'application/json',
      };

  Future<Map<String, String>> _authHeaders() async {
    final token = await _getToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  List<Place> _parsePlaceList(http.Response res) {
    if (res.statusCode != 200) {
      throw Exception('HTTP ${res.statusCode}: ${res.body}');
    }
    final List decoded = json.decode(res.body) as List;
    return decoded
        .map((e) => Place.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  // ── public API ─────────────────────────────────────────────

  /// GET /places?lat=&lng=&radius=
  /// Fetches places within [radius] degrees of the map centre.
  /// Called by PlacesLayer whenever the map moves.
  Future<List<Place>> fetchInBounds({
    required LatLng southWest,
    required LatLng northEast,
    int limit = 1000,
  }) async {
    // Compute centre + radius from the bounding box
    final centerLat = (southWest.latitude + northEast.latitude) / 2;
    final centerLng = (southWest.longitude + northEast.longitude) / 2;
    final radius = ((northEast.latitude - southWest.latitude) / 2)
        .abs()
        .clamp(0.01, 5.0);

    final uri = Uri.parse('$baseUrl/places').replace(queryParameters: {
      'lat': centerLat.toStringAsFixed(6),
      'lng': centerLng.toStringAsFixed(6),
      'radius': radius.toStringAsFixed(6),
    });

    try {
      final res = await http
          .get(uri, headers: _jsonHeaders)
          .timeout(const Duration(seconds: 10));
      return _parsePlaceList(res);
    } on TimeoutException {
      throw Exception(
          'Timeout reaching $baseUrl. '
          'On a real phone use USB + "adb reverse tcp:3000 tcp:3000" '
          'or make sure your phone and PC are on the same Wi-Fi.');
    } on SocketException catch (e) {
      throw Exception('Network error to $baseUrl: ${e.message}');
    }
  }

  /// GET /places/search?q=
  Future<List<Place>> searchPlaces(String query) async {
    final uri = Uri.parse('$baseUrl/places/search')
        .replace(queryParameters: {'q': query});

    try {
      final res = await http
          .get(uri, headers: _jsonHeaders)
          .timeout(const Duration(seconds: 10));
      return _parsePlaceList(res);
    } on TimeoutException {
      throw Exception('Timeout searching places');
    } on SocketException catch (e) {
      throw Exception('Network error: ${e.message}');
    }
  }

  /// GET /places/:id
  Future<Place> fetchPlaceById(String id) async {
    final uri = Uri.parse('$baseUrl/places/$id');

    try {
      final res = await http
          .get(uri, headers: _jsonHeaders)
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 404) throw Exception('Place not found');
      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode}: ${res.body}');
      }
      return Place.fromJson(json.decode(res.body) as Map<String, dynamic>);
    } on TimeoutException {
      throw Exception('Timeout fetching place');
    } on SocketException catch (e) {
      throw Exception('Network error: ${e.message}');
    }
  }

  /// POST /places/:id/rate   (requires auth)
  /// [rating] must be 1–5.
  Future<void> ratePlace(String placeId, int rating) async {
    final uri = Uri.parse('$baseUrl/places/$placeId/rate');

    try {
      final headers = await _authHeaders();
      final res = await http
          .post(
            uri,
            headers: headers,
            body: json.encode({'rating': rating}),
          )
          .timeout(const Duration(seconds: 10));

      if (res.statusCode != 201) {
        final body = json.decode(res.body);
        throw Exception(body['error'] ?? 'Failed to submit rating');
      }
    } on TimeoutException {
      throw Exception('Timeout submitting rating');
    } on SocketException catch (e) {
      throw Exception('Network error: ${e.message}');
    }
  }

  /// GET /places/ratings/my   (requires auth)
  /// Returns all ratings the current user has submitted.
  Future<List<Place>> fetchMyRatings() async {
    final uri = Uri.parse('$baseUrl/places/ratings/my');

    try {
      final headers = await _authHeaders();
      final res = await http
          .get(uri, headers: headers)
          .timeout(const Duration(seconds: 10));
      return _parsePlaceList(res);
    } on TimeoutException {
      throw Exception('Timeout fetching ratings');
    } on SocketException catch (e) {
      throw Exception('Network error: ${e.message}');
    }
  }
}
